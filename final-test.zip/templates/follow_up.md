Write a template follow-up email here. Use any templating language you like. If you don't have a preference, handlebars works fine.
