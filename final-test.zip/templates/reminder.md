Write a template reminder email here. Use any templating language you like. If you don't have a preference, handlebars works fine.
