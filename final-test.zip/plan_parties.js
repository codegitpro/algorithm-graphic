'use strict'

exports.plan_parties = async function () {
  console.log('\x1b[1m Replace `plan_parties.js > plan_parties()` with your matching function. \x1b[0m\n')
}

// These lines allow your function to be called from the command line.
if (require.main === module) {
  exports.plan_parties()
}
