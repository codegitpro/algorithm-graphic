Your code should output a text file here with this format:

# <Dinner theme (string)>
 - <Member Name>, <Title> @ <Company>. Interested in <list of interests>
 - <Member Name>, <Title> @ <Company>. Interested in <list of interests>
 - ...

# <Dinner theme>
 - <Member Name>, <Title> @ <Company>. Interested in <list of interests>
 - <Member Name>, <Title> @ <Company>. Interested in <list of interests>
 - ...

# ...

# Example

# CTOs
 - Elizabeth Warren, CTO @ Package.io. Interested in 1:1s and databases.
 - Pete Buttigieg, CTO @ Shadow Security. Interested in company strategy.
 - Andrew Yang, CTO @ Code for America. Interested in recruiting.
 - Mike Bloomberg, VP Eng @ Billionaire Tech. Interested in recruiting.
 - John Delaney, CTO @ ZenPolling. Interested in databases and company culture.
 - Tulsi Gabbard, CTO @ Rainbow Warrior Shipping. Interested in agile and difficult conversations.

# Recruiting
 - Bernie Sanders - Marketing Manager @ Code for America. Interested in recruiting.
 - Joe Biden - VP Sales @ Package.io. Interested in difficult conversations and recruiting.
 - Amy Klobuchar - CMO @ Code for America. Interested in recruiting and company culture.
 - Deval Patrick - VP Eng @ ZenPolling. Interested in recruiting.
 - Tom Steyer - COO @ Billionaire Tech. Interested in 1:1s and recruiting.
 - Michael Bennet - Managing Director @ Anschutz Investment Company. Interested in recruiting and 1:1s.
